Chapter 6 Programs

wireSphere: wire frame of recursively generated sphere

shadedCube: rotating cube with modified Phong shading

shadedSphere1: shaded sphere using true normals and per vertex shading

shadedSphere2: shaded sphere using true normals and per fragment shading

shadedSphere3: shaded sphere using vertex normals and per vertex shading

shadedSphere4: shaded sphere using vertex normals and per fragment shading

shadedSphereEyeSpace and shadedSphereObjectSpace show how lighting computations can be carried out in these spaces
